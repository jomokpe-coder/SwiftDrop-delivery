SwiftDrop Delivery - Modern Startup React Site
Files:
- public/logo-swiftdrop.png
- public/index.html
- src/index.js
- src/App.js
- src/styles.css
- src/pages/Home.js
- src/pages/Track.js
- src/pages/Contact.js

To run:
1. npm install
2. npm start
